# FlowerShop
It's an online flower shop 

I Used PHP, HTMl, Css, J-query, JavaScript 
the data came from database and the Admin can login with 
* UserName:admin
* Password:password 

And he can add new items and see the list of Orders.
Also Costumers can buy their Favorite Items.
